package simpledatabase;
import java.util.ArrayList;

public class Selection extends Operator{
	
	ArrayList<Attribute> attributeList;
	String whereTablePredicate;
	String whereAttributePredicate;
	String whereValuePredicate;

	
	public Selection(Operator child, String whereTablePredicate, String whereAttributePredicate, String whereValuePredicate) {
		this.child = child;
		this.whereTablePredicate = whereTablePredicate;
		this.whereAttributePredicate = whereAttributePredicate;
		this.whereValuePredicate = whereValuePredicate;
		attributeList = new ArrayList<Attribute>();

	}
	
	
	/**
     * Get the tuple which match to the where condition
     * @return the tuple
     */
	public Tuple next(){
		boolean table = false;
		boolean attr=false;			
		boolean value=false;
		Tuple a = child.next();
		
		if (a==null)
			return null;
		
		if (child.from.equals(whereTablePredicate)||child.from.equals(""))
			table = true;
		else return a;

		Attribute temp = null;
		
		for (int x = 0; x<a.attributeList.size();x++){
			if (a.getAttributeName(x).equals(whereAttributePredicate)){
				attr = true;
				if (a.getAttributeValue(x).equals(whereValuePredicate))					
					value = true;
				}		
		}
		
		if ( table == true && attr==true && value==true){
			return a;
		}
		else {
			return next();
		}
	}
	
	/**
     * The function is used to get the attribute list of the tuple
     * @return the attribute list
     */
	public ArrayList<Attribute> getAttributeList(){
		
		return(child.getAttributeList());
	}

	
}