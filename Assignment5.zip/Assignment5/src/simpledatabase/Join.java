package simpledatabase;
import java.util.ArrayList;

public class Join extends Operator{

	private ArrayList<Attribute> newAttributeList;
	private String joinPredicate;
	ArrayList<Tuple> tuples1;
	ArrayList<Tuple> tuples2;
	int x_post;
	int y_post;
	private boolean init = false;

	
	//Join Constructor, join fill
	public Join(Operator leftChild, Operator rightChild, String joinPredicate){
		this.leftChild = leftChild;
		this.rightChild = rightChild;
		this.joinPredicate = joinPredicate;
		newAttributeList = new ArrayList<Attribute>();
		tuples1 = new ArrayList<Tuple>();
		tuples2 = new ArrayList<Tuple>();
		
	}

	
	/**
     * It is used to return a new tuple which is already joined by the common attribute
     * @return the new joined tuple
     */
	//The record after join with two tables
	@Override
	public Tuple next(){
		
		Tuple a = leftChild.next();		
		Tuple b = rightChild.next();
		
		if(a==null&&b==null)
			return null;
		
		// find the position of common attribute
		if (init==false)
			for ( int x = 0; x <a.attributeList.size();x++) 
				for ( int y = 0; y<b.attributeList.size();y++)
					if (a.getAttributeName(x).equals(b.getAttributeName(y))){
						x_post = x;
						y_post = y;
						init = true;
						}
		//store in array	
		if(a!=null)
		tuples1.add(a);
		if (b!=null)
		tuples2.add(b);
		
		//compare two array and pair up with same value
		for (int i = 0; i<tuples2.size();i++){
			for (int j = 0; j<tuples1.size();j++){
				if (tuples2.get(i).getAttributeValue(y_post).equals(tuples1.get(j).getAttributeValue(x_post)))
					return Merge(tuples1.get(j),tuples2.get(i),i,j);
			}}
		
		return next();
		
	}


	private Tuple Merge(Tuple a, Tuple b,int post,int post2) {
		int a_size = a.attributeList.size();
		int b_size = b.attributeList.size();
		int c = a_size + b_size;
		String[] x1 = new String[c];
		String[] x2 = new String[c];
		String[] x3 = new String[c];
	

		//Merge col
		for (int i = 0; i < a_size;i++){
			x1[i]=a.col[i];
			x2[i]=a.col1[i];
			x3[i]=a.col2[i];
		}
		for (int i = 0; i < b_size; i++){
			x1[i+a_size]=b.col[i];
			x2[i+a_size]=b.col1[i];
			x3[i+a_size]=b.col2[i];			
		}
		
		//set col
		a.col=x1;
		a.col1=x2;
		a.col2=x3;
		
		//remove used value in array
		tuples1.remove(post2);
		tuples2.remove(post);
		
		//reset
		a.setAttributeName();
		a.setAttributeType();
		a.setAttributeValue();
		return a;
	}
	
	
	/**
     * The function is used to get the attribute list of the tuple
     * @return attribute list
     */
	public ArrayList<Attribute> getAttributeList(){
		if(joinPredicate.isEmpty())
			return child.getAttributeList();
		else
			return(newAttributeList);
	}

}