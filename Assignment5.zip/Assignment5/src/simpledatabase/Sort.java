package simpledatabase;
import java.util.ArrayList;
import java.util.Arrays;

public class Sort extends Operator{
	
	private ArrayList<Attribute> newAttributeList;
	private String orderPredicate;
	ArrayList<Tuple> tuplesResult;
	String[] com = new String[50];
	int size = 0;
	int i = 0;
	boolean init = false;
	int count = 0;
	
	
	public Sort(Operator child, String orderPredicate){
		this.child = child;
		this.orderPredicate = orderPredicate;
		newAttributeList = new ArrayList<Attribute>();
		tuplesResult = new ArrayList<Tuple>();
		
	}
	
	
	/**
     * The function is used to return the sorted tuple
     * @return tuple
     */
	@Override
	public Tuple next(){
		Tuple a = child.next();
		
		
		//find position of attribute
		if (init == false)
			for (i = 0;i<a.attributeList.size();i++ )
			if (a.getAttributeName(i).equals(orderPredicate)){
				init = true;
				break;
			}
		if (a==null){
			com = Arrays.copyOf(com, size);
		    Arrays.sort(com, new AlphaNumericStringComparator());
		    for (int x = 0;x<tuplesResult.size();x++)
		   	    	if (com[count].toString().equals(tuplesResult.get(x).getAttributeValue(i).toString())){		    		
		    		count++;
		    		Tuple temp = tuplesResult.get(x);
		    		tuplesResult.remove(x);
		    		return temp;
		    		}		    	
		}
		else {
			com[size] = a.col2[i];
			size++;
			tuplesResult.add(a);
			return next();
		}
		
		return null;
		
	}
	
	/**
     * The function is used to get the attribute list of the tuple
     * @return attribute list
     */
	public ArrayList<Attribute> getAttributeList(){
		return child.getAttributeList();
	}
}